all_brands = '[href="/all-brands?root=topnav_1"]'
adidas = '[href="/designers/adidas/c/7200?root=nav_3&ptype=listing%2Call-brands%2Cadidas%2C1%2Cadidas"]'
get_product = '[href="/adidas-ultraboost-22-heat-rdy-w-white-running-shoes/p/5032404"]'
cart = '[class="css-172e7gk"]'
add_to_bag = '[data-at="add-to-bag"]'
select_size = "//button[@type='button' and contains(text(),'UK 6')]"
move_to_bag = '[data-at="move-to-bag"]'
view_bag = '[data-at="add-to-bag"]'
move_to_wishlist = '[data-at="move-to-wishlist"]'
wishlist_button = '[class="css-potzp0"]'

proceed_to_buy = '[data-at="continue-to-checkout"]'

