url = ""
current_url = "https://www.nykaafashion.com/adidas-ultraboost-22-heat-rdy-w-white-running-shoes/p/5032404"

# Valid Credentials
mobile_number = "7984879566"
otp = ""


# Invalid Credentials
invalid_mobile_number = ""


explicit_wait_time = 10
# implicu?